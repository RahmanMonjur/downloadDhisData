# downloadDhisData
Download program data

DHIS2 is a widely used platform for maintaining individual records. The in-built functionalities of DHIS2 support pivot data for visualisation, mostly for an existing dataset only. This app can be used to download DHIS2 program data in a wide or long format.

In the app, you can select multiple programs (tracker) and choose specific program stages and data elements. The app will merge the respective event data and provide the option to download it in JSON or CSV format. 
